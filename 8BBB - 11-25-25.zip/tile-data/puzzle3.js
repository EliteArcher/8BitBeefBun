// tile-data/puzzle3.js
window.GAME_DATA = {
    title: "Puzzle #3 — Cedan Region",
    tiles: [
        "Lost Cabin", "Honey Glaze Inn", "Trading Outpost", "Observatory",
        "Mountain", "Mountain", "Field", "Field",
        "Old Keep", "The Bay", "Amhurst Farm", "Cedan Castle",
        "Forgarth City", "Rainta Village", "Stables", "Forest"
    ],
    correctLayout: [
        [0],        // slot 0
        [15],        // slot 1
        [4,5],        // slot 2
        [3],        // slot 3
        [6,7],        // slot 4
        [2],       // slot 5
        [8],        // slot 6
        [4,5],        // slot 7
        [14], // slot 8
        [12], // slot 9
        [1],       // slot 10
        [9], // slot 11
        [11],        // slot 12
        [10],       // slot 13
        [6,7],        // slot 14
        [13]         // slot 15
    ],
    clues: [
        "The view of the sky from the Observatory is gorgeous, but it doesn’t provide a very good view of the Bay due to its unfortunate position with two Mountains on its sides.",
        "Honey Glaze Inn is bustling, bursting with travellers heading from Forgarth City to the Bay for vacation.",
        "Vacationers have been swapping ghost stories about the Old Keep North of the Inn, mentioning that the ghosts have been seen in the Keep by climbers on the Mountains.",
        "Crossing the Fields North of the Stables, you feel a chill as you notice an Old Cabin to the West of the Forest. Something tells you not to visit.",
        "The Trading Post North of the City love vacation season; the Farmers to the South, however, are not so pleased with the yearly tradition. ",
        "It seems the Field West of the coastal Rainta Village is being used to prepare some sort of festival by the King in Cedan Castle, who himself was looking forward to a journey East."
    ]
};

