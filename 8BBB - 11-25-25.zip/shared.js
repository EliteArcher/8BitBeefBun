/* ==============================
   SHARED NAVIGATION UTILITIES
   Include this in all HTML files
============================== */

// Navigation helper - eliminates repetitive onclick handlers
function navigateTo(url) {
    window.location.href = url;
}

// Safe navigation with loading state
function navigateWithLoading(url) {
    document.body.style.opacity = '0.7';
    window.location.href = url;
}

/* ==============================
   DATA LOADER FOR GAMES
   Standardized way to load game data
============================== */

// Load game data from external JS file
function loadGameData(dataFile, callback, errorCallback) {
    const script = document.createElement('script');
    script.src = dataFile;
    
    script.onload = () => {
        if (window.GAME_DATA) {
            callback(window.GAME_DATA);
        } else {
            if (errorCallback) errorCallback('Game data not found');
        }
    };
    
    script.onerror = () => {
        if (errorCallback) errorCallback('Failed to load game data');
    };
    
    document.head.appendChild(script);
}

/* ==============================
   LOADING & ERROR STATES
============================== */

function showLoading(containerId, message = 'Loading...') {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = `<div class="loading">${message}</div>`;
    }
}

function showError(containerId, message = 'Something went wrong') {
    const container = document.getElementById(containerId);
    if (container) {
        container.innerHTML = `<div class="error">${message}<br><button class="button-medium" onclick="location.reload()">Retry</button></div>`;
    }
}

/* ==============================
   URL PARAMETER HELPERS
============================== */

function getUrlParam(param, defaultValue = null) {
    const params = new URLSearchParams(window.location.search);
    return params.get(param) || defaultValue;
}

function setUrlParam(param, value) {
    const params = new URLSearchParams(window.location.search);
    params.set(param, value);
    window.history.replaceState({}, '', `${window.location.pathname}?${params}`);
}

/* ==============================
   LOCAL STORAGE HELPERS
   For saving game progress if needed
============================== */

function saveGameProgress(gameKey, data) {
    try {
        localStorage.setItem(`8bbb_${gameKey}`, JSON.stringify(data));
        return true;
    } catch (e) {
        console.error('Failed to save progress:', e);
        return false;
    }
}

function loadGameProgress(gameKey) {
    try {
        const data = localStorage.getItem(`8bbb_${gameKey}`);
        return data ? JSON.parse(data) : null;
    } catch (e) {
        console.error('Failed to load progress:', e);
        return null;
    }
}

function clearGameProgress(gameKey) {
    try {
        localStorage.removeItem(`8bbb_${gameKey}`);
        return true;
    } catch (e) {
        return false;
    }
}

/* ==============================
   KEYBOARD NAVIGATION HELPERS
============================== */

// Add keyboard support for menu buttons
function initKeyboardNav() {
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            const backBtn = document.querySelector('.back-btn');
            if (backBtn && !backBtn.disabled) {
                backBtn.click();
            }
        }
    });
}

// Auto-initialize on page load
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initKeyboardNav);
} else {
    initKeyboardNav();
}