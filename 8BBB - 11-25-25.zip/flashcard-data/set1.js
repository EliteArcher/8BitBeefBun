/* ===========================
   FLASHCARD SET 1 DATA
   - Extracted from the original flashcards-game.html
   - Now follows same pattern as tile puzzle data
=========================== */

window.GAME_DATA = {
    title: "Clue Flashcards",
    
    clues: [
        "Beginning your journey in the small Southeastern-most Town, you hear mention of a Trading Post that is in the unfortunate position of being surrounded on 3 sides by a mighty River",
        "Though there is much untamed land near the City walls, including tell of a Volcano Northward, you are reassured to see a Guard Station just outside the City gates",
        "After visiting the Mines far from the Castle, your ears still ring from the echoing sound of rushing River water that carries Mines from two sides",
        "Leaving the Mine and traveling North, you discover a yet uncharted Cave system, though its proximity to the Volcano does provide ample reason to leave it unexplored",
        "Rumor has it that the Guard Station is less concerned about an attack on the City than they are the Volcano setting fire to the Forest at its Eastern base",
        "Word has travelled from the Southern Trading Outpost that, despite being surrounded by water, they plan to build a road to connect to the faraway Farmland to the North of the Castle and City",
        "While resting in the City, you find yourself gazing at the sunrise over the nearby Castle's great towers.",
        "Travelers on the North Road between Town and the Castle tell you of a cottage to the South of the City that is supposedly home to a great fortune teller. You wonder if you'll ever have the chance to get your own fortune told"
    ],
    
    answer: {
        correctTiles: [
            [9], [13], [3], [4], [11], [14], [2], [0],
            [12], [5], [15], [10], [6], [8], [7], [1]
        ],
        
        tileNames: [
            "Castle","Town","City","Farmland","Farmland","River","River","River",
            "Trading Post","Volcano","Road","Mine","Cave","Forest","Guard Station","Cottage"
        ]
    }
};