// tile-data/puzzle2.js
window.GAME_DATA = {
    title: "Puzzle #2 — Cardaine Region",
    tiles: [
        "Vermail Ranch", "Dartwurst Manor", "Cardaine City", "Cardaine Port",
        "Cardaine Market", "Great Forest", "Military Camp", "The Battlefield",
        "Old Ruins", "Deep Cave", "Farm Field", "Cardaine Watchtower",
        "Leese River", "Leese River", "Leese River", "Bridge"
    ],
    correctLayout: [
        [6],        // slot 0
        [5],        // slot 1
        [4],        // slot 2
        [1],        // slot 3
        [7],        // slot 4
        [11],       // slot 5
        [2],        // slot 6
        [3],        // slot 7
        [12,13,14], // slot 8
        [12,13,14], // slot 9
        [15],       // slot 10
        [12,13,14], // slot 11
        [9],        // slot 12
        [10],       // slot 13
        [0],        // slot 14
        [8]         // slot 15
    ],
    clues: [
        "You stand gazing off the side of a Bridge over the Leese River that divides the land, leaving the Ranch behind and crossing North to Cardaine City",
        "Summoned to Dartwurst Manor to the Northeast of the City, the Duke holds an audience with you to ask about your travels to Vermail Ranch. Seems he has a great deal invested in the Southern soil",
        "You look upon a Battlefield from your perch at the top of the Watchtower just outside the Cardaine City gates. The water from the nearby riverbed has turned the beaten ground to a mud, dirtying the spears and armor still stuck in the ground.",
        "The Easternmost Port is bustling in the morning with goods coming in, all needing to be taken to the nearby Market. The Duke dropped by as well, taking a very quick walk from the Manor to pick up some sensitive items.",
        "Though the Military Camp is as far away from it as possible, the General still wishes to hold training at the Old Ruins. He asks you if the owner of the Ranch next to the Ruins might be willing to provide rations to the training soldiers.",
        "A few merchants in the Cardaine Market tell of a mineral-rich cave in the Southern part of the Land, though it remains untapped due to its poor positioning next to the Duke’s farmland and the Leese River.",
        "As the General marches his soldiers to the Ruins, you inquire about the odd path he takes. He mentions that his soldiers would rather walk through the Forest next to Camp than through the Battlefield South of Camp, as it would improve morale.",
        "The Battalion continues East, and without stopping to shop, continue their journey South the Bridge across the River."
    ]
};
